package com.wacmob.foodhub.data.remote.bean;

/**
 * Created by KP on 1/4/2019.
 */

public class SongListBean {
}
