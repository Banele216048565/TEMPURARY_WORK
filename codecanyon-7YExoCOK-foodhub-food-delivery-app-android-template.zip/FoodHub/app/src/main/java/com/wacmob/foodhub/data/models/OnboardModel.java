package com.wacmob.foodhub.data.models;

public class OnboardModel {
    private int layourResId;

    public OnboardModel(int layourResId) {
        this.layourResId = layourResId;
    }

    public int getLayourResId() {
        return layourResId;
    }

    public void setLayourResId(int layourResId) {
        this.layourResId = layourResId;
    }
}
