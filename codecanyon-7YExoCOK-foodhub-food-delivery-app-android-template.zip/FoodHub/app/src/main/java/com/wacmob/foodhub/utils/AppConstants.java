package com.wacmob.foodhub.utils;

/**
 * Created by KP on 1/18/2019.
 */

public class AppConstants {
    public static final String SUCCESS = "success";
    public static final String FAILURE = "failure";
}
