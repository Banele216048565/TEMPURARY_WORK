package com.wacmob.foodhub.viewmodel;

import com.wacmob.foodhub.base.BaseViewModel;

import javax.inject.Inject;

public class EditProfileViewModel extends BaseViewModel {
    @Inject

    public EditProfileViewModel() {
    }
}
