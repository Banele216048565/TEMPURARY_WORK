package com.wacmob.foodhub.viewmodel;

import com.wacmob.foodhub.base.BaseViewModel;

import javax.inject.Inject;

public class PaymentViewModel extends BaseViewModel {
    @Inject

    public PaymentViewModel() {
    }
}
