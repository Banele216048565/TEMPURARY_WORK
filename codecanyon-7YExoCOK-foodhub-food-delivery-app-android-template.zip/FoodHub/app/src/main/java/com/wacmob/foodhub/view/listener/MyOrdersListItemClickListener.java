package com.wacmob.foodhub.view.listener;

import com.wacmob.foodhub.data.models.MyordersItemModel;

public interface MyOrdersListItemClickListener {

    void click(MyordersItemModel myordersItemModel);
}
