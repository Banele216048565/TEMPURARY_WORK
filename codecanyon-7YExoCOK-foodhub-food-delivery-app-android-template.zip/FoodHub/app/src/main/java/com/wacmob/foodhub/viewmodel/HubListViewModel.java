package com.wacmob.foodhub.viewmodel;

import com.wacmob.foodhub.base.BaseViewModel;

import javax.inject.Inject;

public class HubListViewModel extends BaseViewModel {
    @Inject
    public HubListViewModel() {
    }
}
