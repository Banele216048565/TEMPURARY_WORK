package com.wacmob.foodhub.dagger;

import javax.inject.Qualifier;

/**
 * Created by KP on 1/9/2019.
 */

@Qualifier
//@Retention(RetentionPolicy.RUNTIME)
public @interface ActivityContext {
}
