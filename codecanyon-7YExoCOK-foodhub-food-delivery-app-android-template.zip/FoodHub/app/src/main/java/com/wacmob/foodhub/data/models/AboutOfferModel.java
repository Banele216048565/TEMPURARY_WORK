package com.wacmob.foodhub.data.models;

public class AboutOfferModel {
    String offer;

    public AboutOfferModel(String offer) {
        this.offer = offer;
    }

    public String getOffer() {
        return offer;
    }

    public void setOffer(String offer) {
        this.offer = offer;
    }
}
