package com.wacmob.foodhub.viewmodel;

import com.wacmob.foodhub.base.BaseViewModel;

import javax.inject.Inject;

public class FilterResultViewModel extends BaseViewModel {
    @Inject

    public FilterResultViewModel() {
    }
}
