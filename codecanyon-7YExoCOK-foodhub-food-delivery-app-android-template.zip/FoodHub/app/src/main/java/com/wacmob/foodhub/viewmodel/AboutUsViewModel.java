package com.wacmob.foodhub.viewmodel;

import com.wacmob.foodhub.base.BaseViewModel;

import javax.inject.Inject;

public class AboutUsViewModel extends BaseViewModel {
    @Inject

    public AboutUsViewModel() {
    }
}
