package com.wacmob.foodhub.data.remote;

/**
 * Created by KP on 1/4/2019.
 */

public class ServiceNames {

    public static final String DEV_BASE_URL = "http://www.mocky.io/v2/";
    public static final String PROD_BASE_URL = "http://www.mocky.io/v2/";
    public static final String MOCKY_BASE_URL = "http://www.mocky.io/v2/";


    //END POINTS
    public static final String GET_CONFIG = "prayers_reading_cate";
    public static final String GET_HOME = "prayers_reading_cate";
    //public static final String SEARCH_END_POINT = "5d35b45156000067003a4fa8";
    public static final String SEARCH_END_POINT = "5d368f59560000a2e43a5340";
    public static final String FOOD_LIST_END_POINT = "5d3028103200009301204217";
    public static final String FREE_DELIVERY_LIST_END_POINT = "5d932fa030000078001b72ec";
   // public static final String FREE_DELIVERY_LIST_END_POINT = "5d9329c73000005b001b72a9";

}
