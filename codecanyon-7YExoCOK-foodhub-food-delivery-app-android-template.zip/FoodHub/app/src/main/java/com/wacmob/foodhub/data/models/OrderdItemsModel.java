package com.wacmob.foodhub.data.models;

public class OrderdItemsModel {
    int id, image;

    public OrderdItemsModel(int id, int image) {
        this.id = id;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
