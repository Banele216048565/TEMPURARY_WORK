package com.wacmob.foodhub.data.models;

public class TermsAndConditionsModel {
    String terms;

    public TermsAndConditionsModel(String terms) {
        this.terms = terms;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }
}
