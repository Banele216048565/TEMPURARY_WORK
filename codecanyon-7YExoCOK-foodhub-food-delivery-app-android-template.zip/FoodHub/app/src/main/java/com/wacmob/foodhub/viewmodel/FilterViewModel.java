package com.wacmob.foodhub.viewmodel;

import com.wacmob.foodhub.base.BaseViewModel;

import javax.inject.Inject;

public class FilterViewModel extends BaseViewModel {

    @Inject

    public FilterViewModel() {
    }
}
